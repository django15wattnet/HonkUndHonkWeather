<?php

class ShortCode
{
    readonly float  $lon;
    readonly float  $lat;
    readonly string $value;
    readonly string $headline;
    
    
    public function __construct(array $params)
    {
        $arrError = [];
        
        if (! isset($params['lon'])) {
            $arrError[] = 'Missing parameter lon';
        }
        
        if (! isset($params['lat'])) {
            $arrError[] = 'Missing parameter lat';
        }
        
        if (0 === count($arrError)) {
            // All expected parameter present, check the parameters
            $arrError += $this->checkParameters($params);
        }
        
        if (0 !== count($arrError)) {
            
            $value = '<ul class="error">';
            foreach ($arrError as $msg) {
                $value .= "<li>{$msg}</li>";
            }
            $value .= '</ul>';
            
            $this->value = $value;
            
            return;
        }
        
        if (isset($params['headline'])) {
            $this->headline = $params['headline'];
        } else {
            $this->headline = '';
        }
        
        $this->lon  = floatval($params['lon']);
        $this->lat  = floatval($params['lat']);
        
        try {
            $this->value = $this->getValue();
        } catch (Exception $e) {
            $file = $e->getFile();
            $line = $e->getLine();
            $msg  = $e->getMessage();
            $this->value = "<div class=\"honkWeatherOuter\"><div class=\"error\">{$file}:{$line} - {$msg}</div></div>";
        }
    }
    
    
    /**
     * Not needed at this moment.
     * 
     * @param array $params
     * @return array
     */
    protected function checkParameters(array &$params)
    {
        return [];
    }
    
    
    protected function getValue()
    {
        $nameDataFile = $this->buildSavePath();
        
        if (! file_exists($nameDataFile)) {
            
            touch($nameDataFile);
            throw new Exception("Forecast data not read yet, please come back in about six houres.");
        }
        
        if (false === ($dataJson = file_get_contents($nameDataFile))) {
            throw new Exception("Can't read forecast data: {$nameDataFile}.");
        }
        
        if ('' === $dataJson) {
            throw new Exception("Forecast data not read yet, please come back in about six houres.");
        }
        
        try {
            $dataForecast = json_decode($dataJson, false, 512, JSON_THROW_ON_ERROR);
        } catch (Exception $e) {
            throw new Exception("Can't parse forecast data: {$nameDataFile} -> {$e->getMessage()}.");
        }
        
        return (new Renderer($this, $dataForecast))->value;
    }
    
    
    protected function buildSavePath(): string
    {
        return __DIR__ . '/resources/data/' . $this->lon . '_' . $this->lat;
    }
}

